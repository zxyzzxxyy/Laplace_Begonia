<template>
	<view style="background-color: #f8f8f8;;;width:100vw;height:100vh;background-size: cover;background-attachment: fixed;overflow: hidden;"  v-bind:style="{backgroundImage:'url(' + userbackgroundimage + ')'}"	 id="body">
		<!--顶部栏-->
		<titles style="width:100vw;height:auto;max;min-height: 50px;z-index: 3;" :username="username" :userheadimage="userheadimage" :admin="admin"
		:replymessageshow="replymessageshow"
		></titles>
		<!--center-->
		
		<view style="width:80%;padding-left: 10%;padding-right: 10%;min-heigh:100vh;background-size: cover;background-attachment: fixed;;background-color: #f8f8f8;
		padding-top: 4%;display: flex;;z-index: 1;" 
	 v-bind:style="{backgroundImage:'url(' + userbackgroundimage + ')'}"	
		>
					<!--left-->
			<view style="width: 25.5%;;">
			<view style="width:100%;;height:auto; background-color:white;border-radius: 5px;overflow-y: auto;padding-bottom: 10%;" :style="{'opacity':op}">
				<view v-for="(item,index) in leftlist" style=";" @click="getmore=true;themelist=[];limit=0;getthemelistby_fenlei(item,index),select_fenlei=index" >
					<view style="width:100%;height:25px;display: flex;flex-direction: row;padding-top: 18px;padding-bottom: 18px;color:#818181;align-items: center;">
					<text class="text-blue" style="font-size: 19px;margin-left: 10px;"
					:class="{'text_select':index==select_fenlei}"
					>{{item.title}}</text>
					<text style="margin-left: auto;font-size: 16px;margin-right: 10px;">{{item.num}}</text>
					</view>
					<view style="width:90%;height:0.5px;background-color: #e6e6e6;margin:0 auto"></view>
				</view>
			</view >
			</view>
			<!--center-->
			  
		<scroll-view  style="width:80%;;height:100vh; ;margin-left: 2%;margin-right: 1%;border-radius: 5px;overflow-y: auto;"
		:style="{'opacity':op}"  scroll-y :scroll-top="scroll_top" @scroll="scroll" :scroll-with-animation="true"
		@scrolltoupper="scroll_top=0" @scrolltolower="getthemelistby_fenlei()"
		>
		<view v-if="firstopen()" style="border-radius: 5px;overflow: hidden;">
		  <u-notice-bar :text="message[0]" mode="closable"></u-notice-bar>
		</view>
				<!--<view style="width:100%;height:auto">
					<Xsuu-swiper :swiperItems="swiperItems"
					
					 ></Xsuu-swiper>
				</view>-->
				<!--顶置-->
				<view style="width:96%;font-size: 19px;padding-top: 10px;padding-left: 2%;;background-color: white;border-radius: 5px;padding-right: 2%;">
					<view style="display: flex;flex-wrap: row;">
						<view class="text-blue" style="padding:7px;color:#676767">
						<text :class="{'text_select':type==0}" @click="getmore=true;themelist=[];limit=0;type=0;getthemelistby_fenlei(leftlist[select_fenlei],select_fenlei)">全部</text>
						</view>
						<view class="text-blue" style="padding:7px;color:#676767">
						<text  :class="{'text_select':type==1}" @click="getmore=true;themelist=[];limit=0;type=1;getthemelistby_fenlei(leftlist[select_fenlei],select_fenlei)">精华</text>
						</view>
						<view class="text-blue" style="padding:7px;color:#676767">
						<text  :class="{'text_select':type==2}" @click="getmore=true;themelist=[];limit=0;type=2;getthemelistby_fenlei(leftlist[select_fenlei],select_fenlei)">已关注</text>
						</view>
						<view style="margin-left: auto;width:10%;margin-right: 0%;">
							<u-button type="primary"  text="发布" @click="newtheme()"></u-button>
						</view>
					</view>
					<view style="width:100%;background-color: #e6e6e6;height:1px;margin-top: 15px;margin-bottom: 15px;"></view>
					<!--顶置贴-->
					<view style="min-height: 10px;padding-bottom: 10px;;background-color: white;">
						<view v-for="(item,index) in toplist" style="display: flex;flex-wrap: row;
						padding-right:5%;font-size: 16px;margin-bottom: 5px;
						"
						@click="link(item.themeid)"
						>
							<text style="margin-right: 2%;color:#838383">置顶</text>
							<text style="margin-right: 1%;">{{item.title}}</text>
							<!--<u--text size="16" :lines="1" :text="item.data"></u--text>-->
						</view>
					</view>	
				</view>
				<!--主题-->

				<view v-for="(item,index) in themelist" style="width: 100%;" :style="{'opacity':op}"  v-if="themelist.length!=0">
					
					<view  style="width:96%;height:auto;margin-top: 15px;margin-bottom: 15px;border-radius: 5px;background-color: white;padding:2%;
					padding-left:2%;padding-right: 2%;
					">
						<view style="width: 100%;padding: 0%;display: flex;flex-direction: row;;
						margin-left: 0%;
						">
							<view style="width:50px;margin-right: 5px;height:45px;display: flex;align-items: center;">
							<u-avatar mode="aspectFill":src="item.userheadimage" v-if="item.userheadimage!=null" size="45"></u-avatar>
							<u-avatar :text="item.username.substr(0,1)"  randomBgColor v-if="item.userheadimage==null" size="45"></u-avatar>
							</view>
							<view style="height:45px;display: flex;flex-direction: column;margin-left: 0px;margin-bottom: 10px;width: 100%;">
								<view>
									<view style="display: flex;flex-direction: row; width:100%;">										
									<view style="display: flex;align-items:center">
										<text style="margin-right: 10px;font-size:15px">{{item.username}}</text><text style="font-size: 15px;" v-if="item.shenfen.length!=0">·</text><text style="margin-left:10px;font-size: 14px;color:#909399" v-if="item.shenfen.length!=0">{{item.shenfen}}</text>
									</view>
									<view style="margin-left: auto;margin-right: 2%;display: flex;flex-direction: row;"> 
											<u-tag text="原创"  plain plainFill size="mini" v-if="item.type==0" type="warning"></u-tag>
											<u-tag text="搬运"  plain plainFill size="mini" v-if="item.type==1" type="warning"></u-tag>
											<u-tag text="精华"  plain plainFill size="mini" v-if="item.jing==1" type="error" style="margin-left: 10px;"></u-tag>
										</view>
									
									</view>
									<view style="display: flex;flex-direction: row;align-items: center;">
										<text style="font-size: 14px;color:#838383;margin-right: 5px;">{{time(item.replytime)}}</text>
										<u-icon name="eye"></u-icon>
										<text style="color:#838383;font-size: 15px;margin-left: 2px;">{{item.look}}</text>
									</view>
								</view>
							</view>
						</view>
						<view style="width:90%;margin-left: 5%;margin-right: 5%;display: flex;flex-direction: column;align-items: center;" @click="link(item.themeid)">
							<text style="font-size: 20px;font-weight: 700;margin-bottom:20px">
								{{item.title}}
							</text>
							
							<mp-html
							 :id="'t'+index"
							:content="item.text" 
							style="max-height: 502px;overflow-y: hidden;width:100%;margin-bottom: 25px;"
							/>
							<view style="width:100%;height:80px;background:linear-gradient(to top,rgba(255,255,255,1) 50%,rgba(255,255,255,0) );margin-top: -80px;
							z-index: 2;
							" 
							v-show="jugetops[index]"
							>
								
							</view>
							<view style="width:100%;height:20px;background:rgba(255,255,255,1);margin-top: -20px;
							z-index: 2;display: flex;align-items: center;justify-content: center;flex-direction: row;color:#3c9cff;margin-bottom: 10px;
							" 
							v-show="jugetops[index]"
							>
								查看更多<u-icon name="arrow-down" size=18 color="#3c9cff"></u-icon>
							</view>

							<view v-if="item.image.length==1">
								<view  style="display: flex;width:600px;flex-wrap: warp;">
									<u--image :lazy-load="true" radius="3" :src="item.image[0]+'?imageMogr2/crop/x3000/thumbnail/1000000@'" mode="aspectFill" width="600" style="margin-left: 2.5px;margin-right: 2.5px;"></u--image>
									
								</view>
							</view>
							<view v-if="item.image.length==2">
								<view  style="display: flex;width:600px;flex-wrap: warp;">
									<u--image :lazy-load="true"v-for="(image,index) in item.image" radius="3" :src="image+'?imageMogr2/crop/x3000/thumbnail/1000000@'" mode="aspectFill" width="300" style="margin-left: 2.5px;margin-right: 2.5px;"></u--image>
									
								</view>
							</view>
							<view v-if="item.image.length==3">
								<view  style="display: flex;width:100%;justify-content: center;flex-wrap: warp;">
									<u--image :lazy-load="true"radius="3" :src="item.image[0]+'?imageMogr2/crop/x3000/thumbnail/1000000@'" mode="aspectFill" width="200"></u--image>
									<u--image :lazy-load="true"radius="3" :src="item.image[1]+'?imageMogr2/crop/x3000/thumbnail/1000000@'"  mode="aspectFill" width="200" style="margin-left: 5px;margin-right: 5px;"></u--image>
									<u--image :lazy-load="true"radius="3" :src="item.image[2]+'?imageMogr2/crop/x3000/thumbnail/1000000@'"  mode="aspectFill" width="200"></u--image>
								</view>
							</view>
							<view v-if="item.image.length==4">
								<view style="display: flex;width:100%;justify-content: center;margin-bottom: 0;">
									<u--image :lazy-load="true" radius="3" :src="item.image[0]+'?imageMogr2/crop/x3000/thumbnail/1000000@'" mode="aspectFill" style="min-width: 300px;margin-right: 5px;"></u--image>
									<u--image :lazy-load="true"  radius="3" :src="item.image[1]+'?imageMogr2/crop/x3000/thumbnail/1000000@'"  mode="aspectFill" style="min-width: 300px;margin-left: 5px;"></u--image>
								</view>
								<view style="display: flex;width:100%;justify-content: center;margin-bottom: 0;margin-top: 10px;">
									<u--image :lazy-load="true" radius="3" :src="item.image[2]+'?imageMogr2/crop/x3000/thumbnail/1000000@'" mode="aspectFill"  style="min-width: 300px;margin-right: 5px;"></u--image>
									<u--image :lazy-load="true" radius="3" :src="item.image[3]+'?imageMogr2/crop/x3000/thumbnail/1000000@'"  mode="aspectFill" style="min-width: 300px;margin-left: 5px;"></u--image>
								</view>
							</view>
							
							<view v-if="item.image.length>=5" >
							
								<view style="display: flex;width:100%;justify-content: center;margin-bottom: 0;align-items: center;">
									<u--image  radius="3" :src="item.image[0]+'?imageMogr2/crop/x3000/thumbnail/1000000@'" mode="aspectFill"  style="width: 17.5%;min-width:300px;margin-right: 5px;"></u--image>
									<u--image  radius="3" :src="item.image[1]+'?imageMogr2/crop/x3000/thumbnail/1000000@'"  mode="aspectFill"  style="width:17.5%;min-width:300px;margin-left: 5px;"></u--image>
								</view>
								<view  style="display: flex;width:100%;flex-wrap: warp;margin-top: 5px;">
									<u--image radius="3" :src="item.image[2]+'?imageMogr2/crop/x3000/thumbnail/1000000@'" mode="aspectFill" width="200"></u--image>
									<u--image  radius="3" :src="item.image[3]+'?imageMogr2/crop/x3000/thumbnail/1000000@'"  mode="aspectFill" width="200" style="margin-left: 5px;margin-right: 5px;"></u--image>
									<u--image v-if="item.image.length<=5" radius="3" :src="item.image[4]+'?imageMogr2/crop/x3000/thumbnail/1000000@'"  mode="aspectFill" style="min-;width:11.5%" width="200"></u--image>
									<view v-if="item.image.length>5" style="position: relative;width:11.5%;min-width: 200px;border-radius:3px;overflow: hidden;">
									<u--image  radius="3" :src="item.image[4]+'?imageMogr2/crop/x3000/thumbnail/1000000@'"  mode="aspectFill" width="200" style="position: absolute;z-index: 1;"></u--image>
									<view style="min-width: 200px;width:11.5%;height:100%;position: absolute;z-index: 4;background-color: rgba(0,0,0,0.5);display: flex;align-items: center;justify-content: center;font-size: 50px;color:white">
										+{{item.image.length-5}}
									</view>
									</view>
								</view>
							</view>
							
						</view>

						<view style="display: flex;flex-direction: row;padding-left: 0%;margin-top: 10px;">
						<u-tag v-for="(item,index) in item.tags" :text="item"  icon="tags-fill" style="width: auto;margin-right:10px"  plain plainFill @click="linktag(item)"></u-tag>
						</view>
						
						<view style="display: flex;flex-direction: row;align-items: center;padding:15px;justify-content: center;">
							<view style="display: flex;flex-direction: row;align-items: center;color:#838383" v-show="!jugelike(item.themeid)"
							@click="setlike(item.themeid)"
							>
								<u-icon name="thumb-up"  size="25" style="margin-right: 3px;"></u-icon>
								<text v-if="item.likes==0" style="font-size:17px;">赞</text>
								<text v-if="item.likes!=0" style="font-size: 17px;">{{item.likes}}</text>
							</view>
							<view style="display: flex;flex-direction: row;align-items: center;color:#838383" v-show="jugelike(item.themeid)"
							@click="deletelike(item.themeid)"
							>
								<u-icon name="thumb-up-fill" color="#3c9cff"  size="25" style="margin-right: 3px;" ></u-icon>
								<text  style="font-size: 17px;">{{item.likes}}</text>
							</view>
							<view style="display: flex;flex-direction: row;align-items: center;color:#838383;margin-left: 30%;margin-right: 30%;">
								<u-icon name="chat"  size="25" style="margin-right: 3px;"></u-icon>
								<text  style="font-size: 17px;">{{item.num}}</text>
							</view>
							<view style="display: flex;flex-direction: row;align-items: center;color:#838383">
								<u-icon name="share"  size="25" style="margin-right: 3px;"></u-icon>
								<text  style="font-size: 17px;">分享</text>
							</view>
						</view>
						
						<u-loadmore
							    :status="status" 
							    loading-text="努力加载中" 
							    loadmore-text="轻轻上拉" 
							    nomore-text="实在没有了" 
								v-if="index==themelist.length-1"
								style="margin-top:10px"
						/>
					</view>
				</view>
					<view style="height:100px">
						
					</view>
		</scroll-view>
			
			<!--right-->
		<view style="width:25%;padding-left:1%;padding-right: 1%;">
			<view  style="width:100%;height:400px;max-height: 60vh; background-color:white;padding-left:5%;padding-right: 5%;padding-bottom: 15%;border-radius: 5px;padding-top:10px"
			:style="{'opacity':op}"
			>
				<view style="margin-top: 10px;margin-left: 0%;">
					<text style="font-weight: 700;font-size: 18px;">推荐内容</text>
					<view style="width:100%;background-color: #e6e6e6;height:1px;margin-top: 15px;margin-bottom: 15px;"></view>
				</view>
				<view style="max-height: 70%;margin-bottom: 20%;">
				<view v-for="(item,index) in tuijianlist" style="display: flex;padding:2%;flex-direction: column;margin-bottom: 10px;" v-if="index<3" @click="link(item.themeid)">
					<view style="display: flex;flex-direction: row;align-items: center;">
					<text style="font-size: 12;color:#ee5b20;margin-right: 5%;">{{index+1}}</text>
					<u--text v-if="item.title!=null&&item.title.length>0" :text="item.title"  :lines="1"></u--text>
					<u--text v-if="item.title==null||item.title.length==0" :text="item.data"  :lines="1"></u--text>
					</view>
					<view style="display: flex;flex-direction: row;align-items: center;margin-top: 10px;;margin-left: -3px;">
					<u-icon name="eye" size="14"></u-icon>
					<text style="color:#838383;font-size: 14px;margin-left: 3px;">{{item.look}}</text>
					<u-tag text="精华"   size="medium" type="error"  style="margin-left: auto;" :plainFill="true" :plain="true" ></u-tag>
					</view>
					<view style="width:100%;background-color: #e6e6e6;height:1px;margin-top: 15px;margin-bottom: 15px;"></view>
				</view>
				</view>
				<view style="width: 100%;bottom:0px;display: flex;align-items: center;flex-direction: row;justify-content: center;">
					<u-icon name="reload" size="16"></u-icon>
					<text style="font-size: 16px;color:#838383;margin-left: 5px;" @click="suijituijian()">换一批</text>
				</view>
			</view>
			<view  style="width:100%;height:100px;margin-top:10%; background-color:white;padding-left:5%;padding-right: 5%;padding-bottom: 12%;border-radius: 5px;padding-top:10px;"
			>
			<view style="display:flex;flex-direction: row;">
				<view>
					<image src="../../static/二维码.png" style="width:100px;height:100px"></image>
				</view>
				<view style="margin-left: 5px;display:flex;justify-content: center;flex-direction: column;">
					<view>
					<text style="font-size: 22px;font-weight:800;">扫描下载移动端</text>
					</view>
					<view style="display: flex;align-items:center">
					<image style="height:22px;width:22px;margin-right:5px;margin-top:3px" src="../../static/book.png"></image>
					<text style="font-size: 22px;font-weight:500;color:#707070;">学伴 WMU</text>
					</view>
				</view>
			</view>
				<view @click="beian()" >
					<text   style="font-size: 12px;color:#707070;">吉ICP备2021004411号</text>
				</view>
			</view>
		</view>
		</view>
		<u-toast ref="uToast"></u-toast>
		<view style="width:40px;height:40px;border-radius: 50%;display: flex;align-items: center;justify-content: center;background-color: #3c9cff;
		position: fixed;bottom:20px;z-index: 5;margin-left: 95%;transition-duration:0.3s ;transition:0.3s;opacity: 0;"
		:style="{'opacity':scroll_top1}" @click="backtop()"  v-show="open==1"
		>
			<u-icon name="arrow-up-fill" size="30" style="" color="#ffffff"></u-icon>
		</view>
		<view style="width:40px;height:40px;border-radius: 50%;display: flex;align-items: center;justify-content: center;background-color: #3c9cff;
		position: fixed;bottom:20px;z-index: 5;margin-left:2%;transition-duration:0.3s ;transition:0.3s;opacity: 0;"
		 @click="showopen()"   :style="{'opacity':scroll_top2}"
		>
			<u-icon name="arrow-up-fill" size="30" style="" color="#ffffff"></u-icon>
		</view>
		<view style="width:100%;height:100vh;position: absolute;z-index: 5;transition-duration:1.25s;
		background: linear-gradient(to bottom right, rgb(124, 163, 255) , rgb(16, 216, 255));
		"
		:style="{'margin-Top':show}"	
		@click="showclose()"
		>
		<view  referrer="no-referrer|origin|unsafe-url"  :style="{'backgroundImage':'url(' + showback.url+ ')'}" style="	background-size: cover;background-attachment: fixed;;width:100%;height:100%;background-position:center;">
		<view style="background-color: rgba(0,0,0,0.45);display: flex;flex-direction: row;justify-content:center;align-items: center;height:100vh">
		  <view style="display: flex;flex-direction:column;align-items:center;">
			  <text style="font-size:50px;font-weight:700;color:white;
			  text-shadow:3px 3px black;position: absolute;
			  ">学伴 WMU</text>
			  <view style="margin-top:100px;color:white;font-size:30px;font-weight:700;display:flex;
			  height:200px;width:100vw;justify-content:center;
			  "><text style="  text-shadow:2px 2px black;">{{showlist1}}<text style="
			  " class="re1">|</text></text></view>
			  <view style="position:absolute;top:10px;margin-left:90%;;color:white">
				  <text v-if="!showjuge()" @click.stop="changeshowjuge()">开启自动显示</text>
				  <text v-if="showjuge()"  @click.stop="changeshowjuge()">关闭自动显示</text>
			  </view>
			  <view style="position:absolute;bottom:10px;color:white;">
			  <view  v-if="showback.pid!=null">{{showback.title}} | pid:{{showback.pid}} | 画师：{{showback.username}}</view>
			  </view>
		  </view>
		</view>
		</view>
		</view>
	</view>
</template>

<script>
	import titles from './title.vue'
	 import XsuuSwiper from "../../components/Xss-swiper/Xsuu-swiper.vue"
	export default {
		components:{
			titles,XsuuSwiper
		},
		data() {
			return {
				show:"-108vh",
				showimg:[],
				showback:[],
				replymessagenum:0,
				showlist:[
					"我并不羡慕别人的人生，这就是所谓幸福。——《幸运星》",
					"“如果下雨了，你愿意留下吗？” \n“即使不下雨，我也在这里啊。”\n——《言叶之庭》",
					"只要记住你的名字，不管你在世界的哪个地方，我一定会，去见你。——《你的名字》",
					"曾经发生过的事情不可能忘记，只不过是想不起而已。——《千与千寻》",
					"有思念你的人在的地方,就是你的归处。——《火影忍者》",
					"真正重要的东西，总是没有的人比拥有的人清楚。——《银魂》",
					"真正重要的东西，永远都是非常简单的。——《Clannad》",
					"就算被打得遍体鳞伤，内心也不会简单屈服。——《妖精的尾巴》",
				],
				show1:false,
				showlist1:"",
				showlist1sub:0,
				showsub:0,
				timer:null,
				  swiperItems:[
				                    {
				                            "img": "https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fn.sinaimg.cn%2Fsinacn11%2F440%2Fw744h496%2F20181030%2F97c2-hnaivxq7344712.jpg&refer=http%3A%2F%2Fn.sinaimg.cn&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=jpeg?sec=1619914829&t=52a970d21d4898c8e7ca21b8b5aa9312",
				                            "title": "鲤程新能源",
				                            "Subtitle": "心鲤程，心鲤想！",
				                            "tip": "限时",
				                            "url": "111"
				                        },
				                        {
				                            "img": "https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fs1.xchuxing.com%2Fxchuxing%2Fforum%2F201607%2F27%2F185524zj7wog6qizk9o90k.jpg&refer=http%3A%2F%2Fs1.xchuxing.com&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=jpeg?sec=1619914861&t=4c64a4a5cec709f9d03507b793546646",
				                            "title": "包月低至9.9元",
				                            "Subtitle": "立享受充电礼包！",
				                            "tip": "推荐",
				                            "url": "111"
				                        },
				                        {
				                            "img": "https://gimg2.baidu.com/image_search/src=http%3A%2F%2Finews.gtimg.com%2Fnewsapp_match%2F0%2F11780621658%2F0.jpg&refer=http%3A%2F%2Finews.gtimg.com&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=jpeg?sec=1619914935&t=7d98cfe6b5a2634598fc7bda871aa7c9",
				                            "title": "进口儿童座椅",
				                            "Subtitle": "￥698.99",
				                            "tip": "进口",
				                            "url": "111"
				                        },
				                        {
				                            "img": "https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fstc.zjol.com.cn%2Fg1%2FM000E11CggSDVi-zTuAT1Y3AAB2NSzPgKI097.jpg%3Fwidth%3D576%26height%3D340&refer=http%3A%2F%2Fstc.zjol.com.cn&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=jpeg?sec=1619914972&t=9cc0a578d4818d87c43f1fe839010096",
				                            "title": "品牌T恤",
				                            "Subtitle": "￥22.99",
				                            "tip": "nike",
				                            "url": "111"
				                        }
				                ],
				jugetops:[],
				op:0.95,
				open:0,
				key:"",
				replymessageshow:false,
				status:"loadmore",
				shadowStyle:{
					  // #ifndef APP-NVUE
					    backgroundImage: "linear-gradient(-180deg, rgba(255, 255, 255, 0) 0%, #fff 80%)",
					    // #endif
					    // #ifdef APP-NVUE
					    // nvue上不支持设置复杂的backgroundImage属性
					    backgroundImage: "linear-gradient(to top, #fff, rgba(255, 255, 255, 0.5))",
					    // #endif
					    paddingTop: "100px",
					    marginTop: "-100px",
				},
				title: 'Hello',
				userbackgroundimage:"",
				icon:"/static/icon.png",
				src:"/static/aa.jpg",
				scroll_top:-1,
				scroll_top1:0,
				scroll_top2:1,
				username:"",
				select_fenlei:0,
				fenlei:"全部分类",
				type:0,
				item:"全部分类",
				index:0,
				limit:0,
				getmore:true,
				admin:0,
				mylike:[
					
				],
				tuijian:[

				],
				tuijianlist:[
					
				],
				themelist:[
				],
				toplist:[

				],
				leftlist:[

				],
				upload:[
					{
						type: 'success',
						icon: false,
						title: '成功主题',
						message: "设置成功",
						iconUrl: 'https://cdn.uviewui.com/uview/demo/toast/success.png',
					},
					{
						type: 'error',
						icon: false,
						title: '成功主题',
						message: "设置失败",
						iconUrl: 'https://cdn.uviewui.com/uview/demo/toast/error.png',
					},
					{
						type: 'error',
						icon: false,
						title: '成功主题',
						message: "其它设备登录",
						iconUrl: 'https://cdn.uviewui.com/uview/demo/toast/error.png',
					},
					{
						type: 'error',
						icon: false,
						title: '成功主题',
						message: "请登录",
						iconUrl: 'https://cdn.uviewui.com/uview/demo/toast/error.png',
					}
				],
				message:[]
			}
		},
		onLoad() {
			if(getApp().globalData.showjuge){
				this.show="-108vh";
			}
			else{ this.show="-220vh"}
			this.showsub=uni.$u.random(0, 7);
			this.tests();
			uni.request({
				url:getApp().globalData.http+"/api/getmessage",
				data:{
				},
				method:"POST",
				success: (res) => {
					var temp=[];
					
					for(var i=0;i<getApp().globalData.firstopen.length;i++)
						temp.push(getApp().globalData.firstopen[i]);
					for(var i=0;i<res.data.length;i++){
						if(temp.indexOf(res.data[i].message)==-1){
							var str=res.data[i].message.toString();
							this.message.push(str);
							
						}
					}
					for(var i=0;i<this.message.length;i++)
						getApp().globalData.firstopen.push(this.message[i]);
					uni.setStorage({
					    key: "firstopen",
					    data: getApp().globalData.firstopen,
					    success: function () {
					    }
					});
					
				}
			})
			uni.request({
				url:getApp().globalData.http+"/api/getthemelist",
				data:{
					type:this.type
				},
				method:"POST",
				success: (res) => {
					for(var i=0;i<res.data.data.length;i++){
						this.jugetops.push(false);
						var src=res.data.data[i].image.toString();
						res.data.data[i].image=src.split(";");
						res.data.data[i].image=res.data.data[i].image.slice(0,-1);
						if(res.data.data[i].tags!=undefined){
						res.data.data[i].tags=res.data.data[i].tags.split(";");
						res.data.data[i].tags.pop();
						for(var j=0;j<res.data.data[i].image.length;j++)
							res.data.data[i].image[j]+="";
						}
						res.data.data[i].text=this.test(res.data.data[i].text);
					}
					this.themelist=res.data.data;
					this.limit++;
					this.jugetop();
				}
			})
			uni.request({
				url:getApp().globalData.http+"/api/getthemelist_jing",
				data:{
					
				},
				method:"POST",
				success: (res) => {
					for(var i=0;i<res.data.data.length;i++){
						var src=res.data.data[i].image.toString();
						res.data.data[i].image=src.split(";");
						res.data.data[i].image=res.data.data[i].image.slice(0,-1);
						if(res.data.data[i].tags!=undefined){
						res.data.data[i].tags=res.data.data[i].tags.split(";");
						res.data.data[i].tags.pop();
						}
						res.data.data[i].text=this.test(res.data.data[i].text);
					}
					this.tuijian=res.data.data;
					this.suijituijian();
					////console.log(this.themelist);
				}
			})
			if(getApp().globalData.showjuge)
			this.timer = setInterval( () => {
			    this.showlist2();		
			}, 300)
		},
		onShow() {
			this.replymessageshow=getApp().globalData.replymessageshow;
			let that=this;
			if(getApp().globalData.cookie!='')
			uni.request({
				url:getApp().globalData.http+"/api/jugeuser",
				method:"POST",
				data:{
					"cookie":getApp().globalData.cookie
				},
				success: (res) => {
					if(res.data.code==1002){
						uni.showToast({
							title:"其它设备登录",
							icon:"error"
						})
						getApp().globalData.username='';
						getApp().globalData.userheadimage='';
						getApp().globalData.userbackgroundimage='';
						getApp().globalData.cookie='';
						getApp().globalData.sign='';
						getApp().globalData.save='';
						getApp().globalData.bylike='';
						getApp().globalData.registertime='';
						getApp().globalData.userid='';
						getApp().globalData.admin=0;
						uni.setStorage({
						    key: "admin",
						    data: getApp().globalData.admin,
						    success: function () {
						    }
						});
						uni.setStorage({
						    key: "userid",
						    data: getApp().globalData.userid,
						    success: function () {
						    }
						});
						uni.setStorage({
						    key: "username",
						    data: getApp().globalData.username,
						    success: function () {
						    }
						});
						uni.setStorage({
						    key: "userheadimage",
						    data: getApp().globalData.userheadimage,
						    success: function () {
						    }
						});
						uni.setStorage({
						    key: "userbackgroundimage",
						    data: getApp().globalData.userbackgroundimage,
						    success: function () {
						    }
						});
						uni.setStorage({
						    key: "cookie",
						    data: getApp().globalData.cookie,
						    success: function () {
						    }
						});
						uni.setStorage({
						    key: "save",
						    data: getApp().globalData.save,
						    success: function () {
						    }
						});
						uni.setStorage({
						    key: "bylike",
						    data: getApp().globalData.bylike,
						    success: function () {
						    }
						});
						uni.setStorage({
						    key: "registertime",
						    data: getApp().globalData.registertime,
						    success: function () {
						    }
						});
						setTimeout(() => {
							uni.reLaunch({
								url:"index"
							})
						}
						, 1000)
						
					
					}
					}
				
			})
			if(getApp().globalData.cookie!=''){
				uni.request({
					url:getApp().globalData.http+"/api/getmylike",
					method:"POST",
					data:{
						"cookie":getApp().globalData.cookie,
						"userid":getApp().globalData.userid
					},
					success: (res) => {
						if(res.data.code==1001){
							getApp().globalData.mylike=res.data.mylike
							this.mylike=res.data.mylike;
							
						}
					}
				})
				if(getApp().globalData.cookie!=''){
					uni.request({
						url:getApp().globalData.http+"/api/getmyself",
						method:"POST",
						data:{
							"cookie":getApp().globalData.cookie
						},
						success: (res) => {
							getApp().globalData.admin=res.data.data.admin;
							getApp().globalData.ban=res.data.data.ban;	
							this.admin=getApp().globalData.admin;
							uni.setStorage({
							    key: "admin",
							    data: getApp().globalData.admin,
							    success: function () {
							    }
							});
							uni.setStorage({
							    key: "ban",
							    data: getApp().globalData.ban,
							    success: function () {
							    }
							});
							uni.getStorage({
							    key:"admin",
							    success: function(res){
							        getApp().globalData.admin=res.data;
									//console.log("admin:"+getApp().globalData.admin);
								}
							 });
						}
					})
				}
			}
			uni.request({
				url:getApp().globalData.http+"/api/getfenlei",
				method:"POST",
				data:{
				},
				success: (res) => {
					//console.log(res);
					this.leftlist=[];
					for(var i=0;i<res.data[0].length;i++){
						var temp={
							"title":res.data[0][i],
							"num":res.data[1][i]
						}
						//console.log(temp);
						this.leftlist.push(temp);
					}
					var temp=this.leftlist[this.leftlist.length-1];
					this.leftlist.pop();
					this.leftlist.unshift(temp);
				}
			})
			this.scroll_top1=getApp().globalData.scroll_top1;
			this.userbackgroundimage=getApp().globalData.userbackgroundimage;
			this.username=getApp().globalData.username;
			this.userheadimage=getApp().globalData.userheadimage;
			uni.getStorage({
			    key:"op",
			    success: function(res){
			        getApp().globalData.op=res.data;
					////console.log("admin:"+getApp().globalData.admin);
					this.op=res.data;
				}
			 });
			this.op=getApp().globalData.op;
			uni.request({
				url:getApp().globalData.http+"/api/getthemelist_top",
				data:{
					
				},
				method:"POST",
				success: (res) => {
					//console.log(res.data);
					for(var i=0;i<res.data.data.length;i++){
						var src=res.data.data[i].image.toString();
						res.data.data[i].image=src.split(";");
						res.data.data[i].image=res.data.data[i].image.slice(0,-1);
						if(res.data.data[i].tags!=undefined){
						res.data.data[i].tags=res.data.data[i].tags.split(";");
						res.data.data[i].tags.pop();
						}
						res.data.data[i].text=this.test(res.data.data[i].text);
					}
					this.toplist=res.data.data;
					////console.log(this.themelist);
				}
			})
		},
		computed:{

		},
		methods: {
			tests(){
				uni.request({
					url:getApp().globalData.http+"/api/getpixiv",
					method:"POST",
					data:{
						"type":1
					},
					success: (res) => {
						this.showback=res.data[0];
					}
				})
			},
			showopen(){
				this.show="-108vh";
				this.showsub=uni.$u.random(0, 7);
				this.showlist1sub=0;
				this.timer = setInterval( () => {
				    this.showlist2()
				}, 300)
			},
			showclose(){
			    this.show="-220vh";
				clearTimeout(this.timer);
				this.timer = null;  
				setTimeout(() => {
					clearTimeout(this.timer);
					this.timer = null;  
					this.showlist1="";
				}, 1500)
			},
			showjuge(){
				return getApp().globalData.showjuge;
			},
			changeshowjuge(){
				getApp().globalData.showjuge=!getApp().globalData.showjuge;
				uni.setStorage({
				    key: "showjuge",
				    data: getApp().globalData.showjuge,
				    success: function () {
				    }
				});
			},
		    showlist2(){
				if(this.showlist1sub>=this.showlist[this.showsub].length){
					clearTimeout(this.timer);  
					this.timer = null;  
					setTimeout(() => {   
						this.timer = setInterval( () => {
						     this.showlist3()
						}, 150)
					}, 2500)
				}
				else{
					setTimeout(() => {
						this.showlist1+=this.showlist[this.showsub][this.showlist1sub];
						this.showlist1sub++;
					}, Math.round(Math.random()*100)+150)
				}
			},
			showlist3(){
				if(this.showlist1sub<0){
					this.showlist1="";
					var showsub1=uni.$u.random(0, this.showlist.length-1);
					while(showsub1==this.showsub){
						showsub1=uni.$u.random(0, this.showlist.length-1);
					}
					this.showsub=showsub1;
					this.showlist1sub=0;
					clearTimeout(this.timer);  
					this.timer = null;  
					this.timer = setInterval( () => {
					    this.showlist2()
					}, 300)
				}
				else{
					this.showlist1=this.showlist1.substring(0,this.showlist1sub);
					this.showlist1sub--;
				}
			},
			close1(){
				this.showtime=300;
				this.show=false;
			},
			beian:function(){
				window.location.href="https://beian.miit.gov.cn/"
				
			},
			firstopen(){
				if(this.message.length>0)return true;return false;
			},
			loginout(){
				getApp().globalData.username='';
				getApp().globalData.userheadimage='';
				getApp().globalData.userbackgroundimage='';
				getApp().globalData.cookie='';
				getApp().globalData.sign='';
				getApp().globalData.save='';
				getApp().globalData.bylike='';
				getApp().globalData.registertime='';
				getApp().globalData.userid='';
				getApp().globalData.admin=0;
				uni.setStorage({
				    key: "admin",
				    data: getApp().globalData.admin,
				    success: function () {
				    }
				});
				uni.setStorage({
				    key: "userid",
				    data: getApp().globalData.userid,
				    success: function () {
				    }
				});
				uni.setStorage({
				    key: "username",
				    data: getApp().globalData.username,
				    success: function () {
				    }
				});
				uni.setStorage({
				    key: "userheadimage",
				    data: getApp().globalData.userheadimage,
				    success: function () {
				    }
				});
				uni.setStorage({
				    key: "userbackgroundimage",
				    data: getApp().globalData.userbackgroundimage,
				    success: function () {
				    }
				});
				uni.setStorage({
				    key: "cookie",
				    data: getApp().globalData.cookie,
				    success: function () {
				    }
				});
				uni.setStorage({
				    key: "save",
				    data: getApp().globalData.save,
				    success: function () {
				    }
				});
				uni.setStorage({
				    key: "bylike",
				    data: getApp().globalData.bylike,
				    success: function () {
				    }
				});
				uni.setStorage({
				    key: "registertime",
				    data: getApp().globalData.registertime,
				    success: function () {
				    }
				});
				uni.reLaunch({
					url:"index"
				})
			},
			jugetop:function(){
				let that=this;
				setTimeout(() => {  
				for(var i=0;i<this.themelist.length;i++){
					let info = uni.createSelectorQuery().select("#t"+i);
					　　　  　info.boundingClientRect(function(data) { //data - 各种参数
					　　　  　if(data.height>500)
								that.jugetops[i]=true;  // 获取元素宽度
					}).exec()
				}this.$set(this.jugetops,this.jugetops);
				} , 1)
			},

			linktag:function(e){
				uni.navigateTo({
					url:"tag?tagname="+e
				})
			},
			backtop:function(){
				this.scroll_top=1;
			},

			getthemelistby_fenlei:function(item,index){
				if(item!=undefined)this.item=item.title;
				if(index!=undefined)this.index=index;
				if(this.getmore==false)return ;
				this.getmore=false;
				if(getApp().globalData.cookie==''&&this.type==2){
					this.type=0;
				this.$refs.uToast.show({
					...this.upload[3],
					complete() {
						
					}
				})
				}
				this.status="loading";
				{
					uni.request({
						url:getApp().globalData.http+"/api/getthemelistby_fenlei",
						method:"POST",
						data:{
							"fenlei":this.item,
							"type":this.type,
							"limit":this.limit,
							"userid":getApp().globalData.userid,
							"cookie":getApp().globalData.cookie
						},
						success: (res) => {
							this.limit++;
							this.jugetops=[];
							for(var i=0;i<res.data.data.length;i++){
								var src=res.data.data[i].image.toString();
								res.data.data[i].image=src.split(";");
								res.data.data[i].image=res.data.data[i].image.slice(0,-1);
								if(res.data.data[i].tags!=undefined){
								res.data.data[i].tags=res.data.data[i].tags.split(";");
								res.data.data[i].tags.pop();
								}
								res.data.data[i].text=this.test(res.data.data[i].text);
								this.themelist.push(res.data.data[i]);
								this.jugetops.push(false);
							}
							this.getmore=true;
							setTimeout(() => {
								this.jugetop();
							}, 10)
							if(res.data.data.length<10){
								this.getmore=false;
								this.limit=0;
								this.status="nomore";
								return;
							}
						}
					})
				}
			},
			jugelike:function(res){
				//console.log(this.mylike.length);
				for(var i=0;i<this.mylike.length;i++)
					if(this.mylike[i]==res)return true;return false
			},
			suijituijian:function(){
				var temp=[];
				this.tuijianlist=[];
				if(this.tuijian.length==0)return;
				while(1){

					var i=uni.$u.random(0,this.tuijian.length-1);
					if(temp.indexOf(i)==-1){
						temp.push(i);
					}
					if(temp.length==3||this.tuijian.length==temp.length)
					break;
				}
				for(var i=0;i<temp.length;i++)
				this.tuijianlist.push(this.tuijian[temp[i]]);
				//console.log(this.tuijianlist);
			},
			scroll:function(e){
				
				if(e.detail.scrollTop>20){
					this.open=1;
					setTimeout(() => {this.scroll_top2=0;this.scroll_top1=1, 20})
					
					
				}
				else {this.scroll_top1=0;this.scroll_top2=1}
			},




			setlike:function(e){
				if(getApp().globalData.cookie==''){
					this.$refs.uToast.show({
						...this.upload[3],
						complete() {
							return;
						}
					})
					return;
				}
				uni.request({
					url:getApp().globalData.http+"/api/setmylike",
					method:"POST",
					data:{
						"themeid":e,
						"userid":getApp().globalData.userid,
						"cookie":getApp().globalData.cookie
					},
					success: (res) => {
						//console.log(res.data.code);
						if(res.data.code==1001){
							this.mylike.push(e);
							for(var i=0;i<this.themelist.length;i++){
								if(this.themelist[i].themeid==e){
									this.themelist[i].likes=this.themelist[i].likes+1;break;
								}
							}
							getApp().globalData.mylike=this.mylike;
							
						}
					}
				})
			},
			deletelike:function(e){
				uni.request({
					url:getApp().globalData.http+"/api/deletemylike",
					method:"POST",
					data:{
						"themeid":e,
						"userid":getApp().globalData.userid,
						"cookie":getApp().globalData.cookie
					},
					success: (res) => {
						if(res.data.code==1001){
							for(var i=0;i<this.mylike.length;i++){
								if(this.mylike[i]==e){
									this.mylike.splice(i,1);
									//console.log(this.mylike);
									getApp().globalData.mylike=this.mylike;
									for(var i=0;i<this.themelist.length;i++){
										if(this.themelist[i].themeid==e){
											this.themelist[i].likes=this.themelist[i].likes-1;break;
										}
									}
									break;
								}
							}
							
						}
					}
				})
			},


			test:function(e){
				
				var imgReg = /<img.*?(?:>|\/>)/gi;//定义正则表达式（拿到img标签所有值）
				      
				var deArray  = e.match(imgReg);//使用正则表达式，拿到的是数组
				//["<img src="images/01.gif">", "<img src="images/02.gif">"]
				if (deArray != null && deArray != undefined) {
				        for (var i=0;i<deArray.length;i++) {
				            e = e.replace(deArray[i], "") //放在循环中剔除img标签
				        }
				    }
				var re1 = new RegExp("<br>","g");//匹配html标签的正则表达式，"g"是搜索匹配多个符合的内容
				//e = e.replace(re1,'');//执行替换成空字符
				return e;
			},
			time:function(e){
				var g = new Date().getTime()/1000;
				var time=parseInt(g)-parseInt(e);
				if(time<60)
					return "回复于"+parseInt(time)+"秒前";
				else if(time>=60&&time<60*60)
					return "回复于"+parseInt(time/60)+"分钟前";
				else if(time>=60*60&&time<60*60*24)
					return "回复于"+parseInt(time/60/60)+"小时前"
				else{
					var g = new Date().getTime();
					var d = new Date(g);
					var e = new Date(e*1000);
					var year = d.getFullYear(); 
					var month = d.getMonth() + 1; //取得日期中的月份，其中0表示1月，11表示12月
					var date = d.getDate(); 
					var year1 = e.getFullYear();
					var month1 = e.getMonth() + 1; //取得日期中的月份，其中0表示1月，11表示12月
					var date1 = e.getDate(); 
					if(year!=year1)
						return year1+"-"+month1+"-"+date1;
					else return month1+"-"+date1;
				}
			},
			link:function(e){
				uni.request({
					url:getApp().globalData.http+"/api/lookadd",
					method:"POST",
					data:{
						"themeid":e
					},
					success: (res) => {
						;
					}
				})
				uni.navigateTo({
					url:"theme?themeid="+e
				})
			},
			newtheme:function(){
				if(getApp().globalData.cookie==''){
					uni.showToast({
						title:"请登录",
						icon:"error"
					})
					return;
				}
				uni.navigateTo({
					url:"newtheme"
				})
			},

		}
	}
</script>

<style>
	.text-blue :hover{
		color:#2469f6
	}
	.op{
		opacity: 0.95;
	}
	.op1{
		background:rgba(255, 255, 255, 0);
	}
	.text_select {
		color:#2469f6;
		font-weight: 800;
	}
	.re1{
		animation: myfirst 1s linear  normal infinite;
	}
	@keyframes myfirst
	{
		0%{
			opacity: 0;
		}
		50%{
			opacity: 1;
		}
		100%{
			opacity: 0;
		}
	}
</style>
